import pandas as pd  
import plotly.express as px  
import streamlit as st  


st.set_page_config(page_title="Transport", page_icon=":station:", layout="wide")

# ---- READ EXCEL ----
@st.cache_data
def get_data_from_excel():
    df = pd.read_excel(
        io="Passenger Journeys by Luas.xlsx",
        engine="openpyxl",
        sheet_name="Unpivoted",
        # skiprows=3,
        usecols="C:H",
        nrows=793,
    )

    return df

df = get_data_from_excel()

# ---- SIDEBAR ----
st.sidebar.header("Please Filter Here:")
line = st.sidebar.multiselect(
    "Select the Luas Line:",
    options=df["Luas_Line"].unique(),
    default="Green line"
)

tlist = st.sidebar.multiselect(
    "Select the T_LIST_Week:",
    options=df["T_LIST_Week"].unique(),
    default="2019W01",
)



df_selection = df.query(
    "Luas_Line == @line & T_LIST_Week ==@tlist"
)

# Check if the dataframe is empty:
if df_selection.empty:
    st.warning("No data available based on the current filter settings!")
    st.stop() # This will halt the app from further execution.

# ---- MAINPAGE ----
st.title(":station: Transport Data")
st.markdown("##")



passengers_by_week =df_selection.groupby(by=["T_LIST_Week"])[["VALUE"]].sum().sort_values(by="VALUE") 
# print(passengers_by_week.index)
fig_pass = px.histogram(
    passengers_by_week,
    x=passengers_by_week.index,
    y="VALUE",
    orientation="v",
    title="<b>Passengers by Week</b>",
    color_discrete_sequence=["#B6E880"] * len(passengers_by_week),
    template="plotly_white",
)
fig_pass.update_layout(
    plot_bgcolor="rgba(0,0,0,0)",
    xaxis=(dict(showgrid=False))
)


passengers_by_luas =df_selection.groupby(by=["Luas_Line"])[["VALUE"]].sum().sort_values(by="VALUE") 
# print(passengers_by_luas.index)
fig_lua = px.histogram(
    passengers_by_luas,
    x=passengers_by_luas.index,
    y="VALUE",
    orientation="v",
    title="<b>Passengers by Lua</b>",
    color_discrete_sequence=["#636EFA"] * len(passengers_by_luas),
    template="plotly_white",
)
fig_lua.update_layout(
    plot_bgcolor="rgba(0,0,0,0)",
    xaxis=(dict(showgrid=False))
)


left_column, right_column = st.columns(2)
left_column.plotly_chart(fig_lua, use_container_width=True)
right_column.plotly_chart(fig_pass, use_container_width=True)


# ---- HIDE STREAMLIT STYLE ----
hide_st_style = """
            <style>
            #MainMenu {visibility: hidden;}
            footer {visibility: hidden;}
            header {visibility: hidden;}
            </style>
            """
st.markdown(hide_st_style, unsafe_allow_html=True)
